import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("I can do your addition for you!");
    int hashtagValue = scan.nextInt();
    int count = 1;
    int sum = 0;
      
    while ( count < 11 && hashtagValue != 0)
    {
    count += 1;
    System.out.println("Please input another number" + hashtagValue);
    sum += hashtagValue;
    hashtagValue = scan.nextInt();
    }
  System.out.println("The sum of the number is " + sum);
  }
}